RTP Brain Console UI (Static)
--------------------------------
Upload these files to Cloudflare Pages (or any static host).

- Set Base URL (top right) to your deployed Worker, e.g.:
  https://rtp-brain-v2.kbroxton23.workers.dev

Tabs:
- Matchups: POST /matchup/sim
- Teams: POST /teams/ingest, POST /teams/upload (CSV), GET /teams/get, GET /teams/export.csv
- Props: POST /props/upload (CSV/JSON), GET /props/list, POST /props/sim, POST /props/eval, GET /props/export.csv
- Lines: GET /game-lines, GET /edges/games, GET /anchors/nfl
- Injuries: POST /injuries/ingest
- Calibration: /cal/* helpers
- Endpoint Lab: call any route (GET/POST)

CSV Upload:
- Uses multipart form-data with field name "file" plus season/week fields.

CSV Download:
- Click "Download" in the output panel to save the CSV locally.
