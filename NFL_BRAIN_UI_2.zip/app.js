// RTP Brain UI — NFL (Cloudflare Pages static)
// This UI is intentionally "dumb": it just calls Worker endpoints and renders JSON.
// Key fix: Market inputs are OPTIONAL and we NEVER send 0 as a line (we send null/omit).

const $ = (sel) => document.querySelector(sel);
const $$ = (sel) => Array.from(document.querySelectorAll(sel));

// Minimal notifier for mobile (keeps "nothing happened" confusion down)
function toast(msg) {
  try {
    logLine(String(msg), 'warn');
  } catch (_) {}
  try {
    // also reflect in the global output box if available
    const el = $('#out');
    if (el && !el.textContent) el.textContent = String(msg);
  } catch (_) {}
}

const LS_BASE = 'rtp_worker_base_url';
// Default so first-time deploy works immediately (user can override in UI)
const DEFAULT_BASE_URL = 'https://rtp-brain-v2.kbroxton23.workers.dev';

function now() {
  return new Date().toISOString();
}

function pretty(x) {
  return typeof x === 'string' ? x : JSON.stringify(x, null, 2);
}

function setOut(x) {
  const el = $('#out');
  if (el) el.textContent = pretty(x);
}

function setBox(id, x) {
  const el = $(id);
  if (!el) return;
  el.textContent = pretty(x);
}

function logLine(msg, kind = 'info') {
  const el = $('#log');
  if (!el) return;
  const line = `[${now()}] ${msg}`;
  el.textContent = (el.textContent ? el.textContent + '\n' : '') + line;
  el.dataset.kind = kind;
}

function baseUrlGet() {
  let v = ($('#baseUrl')?.value || '').trim();
  // If user left the placeholder or empty, fall back to the known worker base.
  if (!v || /<.*>/.test(v) || v.includes('your-worker')) v = DEFAULT_BASE_URL;
  v = v.replace(/\/+$/, '');
  // Very light validation – avoid silent failures.
  if (!/^https?:\/\//i.test(v)) return '';
  return v;
}

function baseUrlSet(v) {
  const el = $('#baseUrl');
  if (el) el.value = v || '';
}

function safeJsonParse(text) {
  try {
    return { ok: true, value: JSON.parse(text) };
  } catch {
    return { ok: false };
  }
}

async function fetchJson(path, opts = {}) {
  const base = baseUrlGet();
  if (!base) throw new Error('Missing Worker Base URL');

  const url = base + path;
  const started = performance.now();

  const headers = Object.assign({ Accept: 'application/json' }, opts.headers || {});
  const init = Object.assign({}, opts, { headers });

  logLine(`${init.method || 'GET'} ${path} …`);
  const res = await fetch(url, init);
  const text = await res.text();
  const ms = Math.round(performance.now() - started);

  const parsed = safeJsonParse(text);
  const payload = parsed.ok ? parsed.value : { ok: true, data: text, _raw: text };

  if (!res.ok) {
    logLine(`✖ ${res.status} ${res.statusText} • ${ms}ms • ${path}`, 'bad');
    setOut(payload);
    throw new Error(`HTTP ${res.status}`);
  }

  logLine(`✔ ${res.status} • ${ms}ms • ${path}`, 'good');
  return payload;
}

// ---- Odds helpers (for UI display only)
function americanToDecimal(odds) {
  if (typeof odds !== 'number' || !Number.isFinite(odds) || odds === 0) return null;
  return odds > 0 ? 1 + (odds / 100) : 1 + (100 / Math.abs(odds));
}

function americanToProb(odds) {
  const dec = americanToDecimal(odds);
  if (!dec) return null;
  return 1 / dec;
}

function readNum(id) {
  const raw = ($(id)?.value ?? '').toString().trim();
  if (!raw) return null;
  const n = Number(raw);
  return Number.isFinite(n) ? n : null;
}

function readText(id) {
  return (($(id)?.value ?? '') + '').trim();
}

function buildMarketFromUI() {
  // IMPORTANT: Never send 0 for total. For spread, 0 can be valid PK, but only if the user explicitly typed 0.
  const spreadHome = readNum('#msMarketSpreadHome');
  const total = readNum('#msMarketTotal');

  const market = {};
  if (spreadHome !== null) market.spread_home = spreadHome;
  if (total !== null && total !== 0) market.total = total;

  // Optional odds: only send if user typed them.
  const odds = {
    ml_home: readNum('#msOddsMlHome'),
    ml_away: readNum('#msOddsMlAway'),
    spread_home: readNum('#msOddsSpreadHome'),
    spread_away: readNum('#msOddsSpreadAway'),
    over: readNum('#msOddsOver'),
    under: readNum('#msOddsUnder'),
  };
  const oddsClean = Object.fromEntries(Object.entries(odds).filter(([, v]) => v !== null));
  if (Object.keys(oddsClean).length) {
    market.odds = oddsClean;

    // Lift ML odds to top-level keys so the Worker can grade ML
    if (oddsClean.ml_home != null) { market.ml_home = oddsClean.ml_home; market.ml_odds_home = oddsClean.ml_home; }
    if (oddsClean.ml_away != null) { market.ml_away = oddsClean.ml_away; market.ml_odds_away = oddsClean.ml_away; }


    // Convenience aliases so the Worker can always find a single spread/total odds,
    // while still keeping the full per-side odds object.
    market.spread_odds = oddsClean.spread_home ?? oddsClean.spread_away ?? null;
    market.total_odds = oddsClean.over ?? oddsClean.under ?? null;
  }

  return {
    spread_home: market.spread_home ?? null,
    total: market.total ?? null,
    spread_odds: market.spread_odds ?? null,
    total_odds: market.total_odds ?? null,
    ml_home: market.ml_home ?? null,
    ml_away: market.ml_away ?? null,
    ml_odds_home: market.ml_odds_home ?? null,
    ml_odds_away: market.ml_odds_away ?? null,
    odds: market.odds ?? null
  };
}

function buildGradeFlags(mode) {
  const m = (mode || 'both').toLowerCase();
  return {
    with_model: m === 'model' || m === 'both',
    with_market: m === 'market' || m === 'both'
  };
}


function wireTabs() {
  const tabs = $$('.tab');
  const panels = $$('.panel');

  const setActive = (name) => {
    for (const t of tabs) {
      const on = t.dataset.tab === name;
      t.classList.toggle('is-active', on);
      t.setAttribute('aria-selected', on ? 'true' : 'false');
    }
    for (const p of panels) {
      const on = p.id === `tab-${name}`;
      p.classList.toggle('is-active', on);
      p.setAttribute('aria-hidden', on ? 'false' : 'true');
    }
  };

  tabs.forEach((t) => t.addEventListener('click', () => setActive(t.dataset.tab)));
}

function wireBaseUrl() {
  const saved = (localStorage.getItem(LS_BASE) || '').trim();
  if (saved) {
    baseUrlSet(saved);
  } else {
    // If the user hasn't set anything yet, prefill a working default
    baseUrlSet(DEFAULT_BASE_URL);
    localStorage.setItem(LS_BASE, DEFAULT_BASE_URL);
  }

  const el = $('#baseUrl');
  if (!el) return;
  const persist = () => {
    const v = baseUrlGet();
    if (!v) {
      toast('Set a valid Worker Base URL first.', 'warn');
      return;
    }
    localStorage.setItem(LS_BASE, v);
    logLine(`Base URL saved • ${v}`);
  };
  el.addEventListener('change', persist);
  el.addEventListener('blur', persist);
}

function wireOddsLiveHints() {
  const pairs = [
    ['#msOddsMlHome', '#msImpMlHome'],
    ['#msOddsMlAway', '#msImpMlAway'],
  ];
  for (const [inp, out] of pairs) {
    const el = $(inp);
    const dst = $(out);
    if (!el || !dst) continue;
    const update = () => {
      const n = readNum(inp);
      const p = n === null ? null : americanToProb(n);
      dst.textContent = p === null ? '' : `implied ${(p * 100).toFixed(2)}% (0–1: ${p.toFixed(4)})`;
    };
    el.addEventListener('input', update);
    update();
  }
}

function renderAnchorsCards(resp) {
  const host = $('#anchorsCards');
  if (!host) return;
  host.innerHTML = '';

  const buckets = [
    ['Totals', resp?.data?.anchors?.totals || []],
    ['Spread', resp?.data?.anchors?.spread || []],
    ['Moneyline', resp?.data?.anchors?.moneyline || []],
  ];

  for (const [title, arr] of buckets) {
    const card = document.createElement('div');
    card.className = 'card';
    card.innerHTML = `<h3>${title} <span class="muted">(${arr.length})</span></h3>`;

    if (!arr.length) {
      const d = document.createElement('div');
      d.className = 'muted';
      d.textContent = 'None.';
      card.appendChild(d);
      host.appendChild(card);
      continue;
    }

    const list = document.createElement('div');
    list.className = 'cards';

    for (const it of arr.slice(0, 25)) {
      const pick = it.pick || {};
      const pv = it.prob_view || {};
      const mv = it.model_view || {};

      const row = document.createElement('div');
      row.className = 'card';
      row.innerHTML = `
        <div style="display:flex; justify-content:space-between; gap:10px; align-items:flex-start">
          <div>
            <div style="font-weight:700">${it.away_name} @ ${it.home_name}</div>
            <div class="muted" style="margin-top:2px">${pick.market} • ${pick.side ?? ''} ${pick.line ?? ''} • grade ${pick.grade ?? '—'} • ${pick.confidence ?? '—'}</div>
          </div>
          <div style="text-align:right">
            <div class="muted">p_model ${(pv.p_model ?? 0).toFixed(3)}</div>
            <div class="muted">edge ${(pv.edge_prob ?? 0).toFixed(3)}</div>
            <div class="muted">EV ${(pv.ev_1u ?? 0).toFixed(3)}</div>
          </div>
        </div>
        <div class="muted" style="margin-top:8px">model spread_home ${mv.spread_home ?? '—'} • total ${mv.total ?? '—'} • win ${(mv.ml_home ?? 0).toFixed(3)}/${(mv.ml_away ?? 0).toFixed(3)}</div>
      `;
      list.appendChild(row);
    }

    card.appendChild(list);
    host.appendChild(card);
  }
}

function wireActions() {
  // Header quick actions
  $('#btnPing')?.addEventListener('click', async () => {
    const resp = await fetchJson('/');
    setOut(resp);
  });
  $('#btnHealth')?.addEventListener('click', async () => {
    const resp = await fetchJson('/health');
    setOut(resp);
  });

  // Status tab
  $('#btnStatus')?.addEventListener('click', async () => {
    const resp = await fetchJson('/status');
    setOut(resp);
  });
  $('#btnRoot')?.addEventListener('click', async () => {
    const resp = await fetchJson('/');
    setOut(resp);
  });

  // Lines
  $('#btnGameLines')?.addEventListener('click', async () => {
    const sport = readText('#linesSport') || 'nfl';
    const qs = sport ? `?sport=${encodeURIComponent(sport)}` : '';
    const resp = await fetchJson(`/game-lines${qs}`);
    setBox('#outLines', resp);
    setOut(resp);
  });

  // Calibration
  $('#btnCalFit')?.addEventListener('click', async () => {
    const season = readText('#calSeason');
    const week = readText('#calWeek');
    const parts = [];
    if (season) parts.push(`season=${encodeURIComponent(season)}`);
    if (week) parts.push(`week=${encodeURIComponent(week)}`);
    const qs = parts.length ? `?${parts.join('&')}` : '';
    const resp = await fetchJson(`/cal/fit${qs}`);
    setBox('#outCal', resp);
    setOut(resp);
  });

  // Matchup sim
  $('#btnMatchupSim')?.addEventListener('click', async () => {
    const btn = $('#btnMatchupSim');
    const prevText = btn ? btn.textContent : '';
    if (btn) { btn.disabled = true; btn.textContent = 'Running…'; }
	try {
    const season = readNum('#msSeason');
    const week = readNum('#msWeek');
    const home = readText('#msHome').toUpperCase();
    const away = readText('#msAway').toUpperCase();
    const weights = readText('#msWeights');

    const modifiers = {
      enabled: !!$('#modEnabled')?.checked,
      use_non_garbage: !!$('#modNonGarbage')?.checked,
      use_early_down: !!$('#modEarlyDown')?.checked,
      use_late_down: !!$('#modLateDown')?.checked,
      use_red_zone: !!$('#modRedZone')?.checked,
      blend_mode: readText('#modBlend') || 'dual',
      pure_weight: readNum('#modPureW') ?? 0.7,
      mods_weight: readNum('#modModsW') ?? 0.3,
    };

    const market = buildMarketFromUI();
    const gradeMode = ($('#msGradeMode')?.value || 'both');
    const grade = buildGradeFlags(gradeMode);

    const body = {
      season,
      week,
      home,
      away,
      weights: weights || null,
      modifiers,
      market,
      grade_mode: gradeMode,
      grade,
    };

    // Guardrails: warn when grading needs a market line but it's missing.
    if ((gradeMode === 'both' || gradeMode === 'market') && (market.total == null)) {
      logLine('Market total missing → total grading/anchors will be skipped. Enter a Total line or switch Grade Mode to Model.', 'warn');
    }
    if ((gradeMode === 'both' || gradeMode === 'market') && (market.spread_home == null)) {
      logLine('Market spread missing → spread grading/anchors will be skipped. Enter a Spread line or switch Grade Mode to Model.', 'warn');
    }
	const resp = await fetchJson('/matchup/sim', {
	  method: 'POST',
	  headers: { 'Content-Type': 'application/json' },
	  // Send using the Worker-preferred envelope. (Worker also accepts the
	  // flat body for backward compat, but this avoids "missing_teams" errors.)
	  body: JSON.stringify(body),
	});
	setOut(resp);
	// Auto-scroll to response on mobile so it feels responsive
	$('#out')?.scrollIntoView?.({ behavior: 'smooth', block: 'start' });
	} catch (e) {
		setOut({ ok: false, error: String(e) });
		toast(String(e));
	} finally {
		if (btn) { btn.disabled = false; btn.textContent = prevText || 'POST /matchup/sim'; }
	}
  });

  // Anchors
  $('#btnAnchorsNFL')?.addEventListener('click', async () => {
    const season = readText('#anchorsSeason');
    const week = readText('#anchorsWeek');
    const parts = [];
    if (season) parts.push(`season=${encodeURIComponent(season)}`);
    if (week) parts.push(`week=${encodeURIComponent(week)}`);
    const qs = parts.length ? `?${parts.join('&')}` : '';
    const resp = await fetchJson(`/anchors/nfl${qs}`);
    setBox('#outAnchors', resp);
    renderAnchorsCards(resp);
    setOut(resp);
  });

  $('#btnAnchorsToday')?.addEventListener('click', async () => {
    const resp = await fetchJson('/anchors/today');
    setBox('#outAnchors', resp);
    renderAnchorsCards(resp);
    setOut(resp);
  });

  // Utility buttons (Log panel)
  $('#btnClear')?.addEventListener('click', () => {
    if ($('#log')) $('#log').textContent = '';
    setOut('');
  });
  $('#btnCopy')?.addEventListener('click', async () => {
    const t = $('#out')?.textContent || '';
    await navigator.clipboard.writeText(t);
    logLine('Copied response to clipboard.');
  });
}

function boot() {
  wireTabs();
  wireBaseUrl();
  wireOddsLiveHints();
  wireActions();
  logLine('UI booted.');
}

window.addEventListener('DOMContentLoaded', boot);
